(function() {

  return {
    events: {
      'app.activated':'doSomething'
    },

    doSomething: function() 
    }
  };

}());
a