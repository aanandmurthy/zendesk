# 100Worte name

Install Of App in Zendesk

1.	In Zendesk Support, click the Admin icon ( ) in the sidebar, then select Manage from the Apps category.
2.	Click Upload Private App in the upper-right corner of the page.
3.	Enter the name of your app (Requester X-ray). If you did the tutorial for ZAF v1 and installed the app, use a slightly different name for this second version of the app.
4.	Click Choose File and select the zip file of your app.
5.	Click Upload to upload the app to Zendesk Support, then again after reading the risks and limitations.
6.	When prompted, click Install.
7.	When the process ,app will appear as private app in your list of installed app on page
